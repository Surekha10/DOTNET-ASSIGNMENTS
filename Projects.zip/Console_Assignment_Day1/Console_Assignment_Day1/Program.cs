﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment_Day1
{
    class Program
    {
        static void Main(string[] args)
        {
            int number1;
            int number2;
            string operand;

            Console . WriteLine("Enter First Number:");
            number1 = Convert.ToInt32(Console.ReadLine());

            Console . WriteLine("Choose Operand(-,+,/,*)");
            operand = Console.ReadLine();

            Console.WriteLine("Enter Second Number:");
            number2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("the result is :");

            if (operand == "-")
                Console.WriteLine(number1 - number2);

            if (operand == "+")
                Console.WriteLine(number1 + number2);

            if (operand == "/")
                Console.WriteLine(number1 / number2);

            if (operand == "*")
                Console.WriteLine(number1 * number2);

            Console.ReadKey();


        }
    }
}
