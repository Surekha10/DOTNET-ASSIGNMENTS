﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee
{
    class Employee :IHR_Emp,IAccountEmp,IManagerEmp
    {
        private int EmployeeId;
        private String EmployeeName;
        private String EmployeeCity;
        private int EmployeeSalary;
        private String EmployeeAddress;
        private String EmployeeProjectDetails;
        private int EmployeeExp;
        private int EmployeeAccNo;
        private String AccBankName;
        private int Age;
        private static int count = 1000;

        public Employee(int EmployeeId,String EmployeeName,String EmployeeCity,int EmployeeSalary,String EmployeeAddress,
            string EmployeeProjectDetails,int EmployeeExp,int EmployeeAccNo,String AccBankName,int Age)
        {
            this.EmployeeId = EmployeeId;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeProjectDetails = EmployeeProjectDetails;
            this.EmployeeExp = EmployeeExp;
            this.EmployeeAccNo = EmployeeAccNo;
            this.AccBankName = AccBankName;
            this.Age = Age;


        }

        public string GetEmployeeAddress()
        {
            return this.EmployeeAddress;
        }

        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }

        public int GetEmployeeId()
        {
            return this.EmployeeId;
        }

        public int GetEmployeeAccountNo()
        {
            return this.EmployeeAccNo;
        }

        public int GetEmployeeExP()
        {
            return this.EmployeeExp;
        }

        public string GetEmployeeProjectDetails()
        {
            return this.EmployeeProjectDetails;
        }
    } 
}
