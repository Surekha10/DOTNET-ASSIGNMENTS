﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee
{
    class Manager
    {
        public void GetEmployee(IManagerEmp obj)
        {
            int Exp =obj.GetEmployeeExP();
            Console.WriteLine("EmpExp:" + Exp);
            int Id =obj.GetEmployeeId();
            Console.WriteLine("EmpId:" + Id);
           String Details= obj.GetEmployeeProjectDetails();
            Console.WriteLine("EmpDetails:" + Details);
        }
    }
}
