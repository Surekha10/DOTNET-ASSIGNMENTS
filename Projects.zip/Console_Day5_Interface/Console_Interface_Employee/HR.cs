﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee
{
    class HR
    {
        public void GetEmployee(IHR_Emp obj)
        {
            String Address=obj.GetEmployeeAddress();
            Console.WriteLine("EmpAddress:" + Address);
            int Id= obj.GetEmployeeId();
            Console.WriteLine("EmpId:" + Id);
            int Salary =obj.GetEmployeeSalary();
            Console.WriteLine("EmpSalary:" + Salary);

        }
    }
}
