﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee
{
    interface IHR_Emp
    {
        String GetEmployeeAddress();
        int GetEmployeeSalary();
        int GetEmployeeId();
    }
}
