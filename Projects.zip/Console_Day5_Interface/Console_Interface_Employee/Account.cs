﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee
{
    class Account
    {
        public void GetEmployee(IAccountEmp obj)
        {
            int AccountNo =obj.GetEmployeeAccountNo();
            Console.WriteLine("EmpAccNo:" + AccountNo);
            int id =obj.GetEmployeeId();
            Console.WriteLine("EmpId:" + id);
             int Salary =obj.GetEmployeeSalary();
            Console.WriteLine("EmpSalary:" + Salary);
        }
    }
}
