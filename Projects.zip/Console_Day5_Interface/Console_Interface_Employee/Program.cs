﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj = new Employee(1001, "Surekha", "Bang", 4500, "JpNagar", "abcd", 7, 12345, "SBI", 23);

            HR obj1 = new HR();
            obj1.GetEmployee(obj);
            Account obj2 = new Account();
            obj2.GetEmployee(obj);
            Manager obj3 = new Manager();
            obj3.GetEmployee(obj);
            Console.ReadLine();
        }

    }
}
