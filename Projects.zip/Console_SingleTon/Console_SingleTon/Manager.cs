﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_SingleTon
{
    class Manager
    {
        private int ManagerID;
        private String ManagerName;
        
        private Manager(int ManagerID,string ManagerName)
        {
            this.ManagerID = ManagerID;
            this.ManagerName = ManagerName;
        }

        static Manager m = null;
        public static Manager GetManager()
        {
            if (m == null)
            {
                Manager m = new Manager(1001, "sweety");
            } 
            return m;
        }
        public int pManagerID { get {  return this.ManagerID; } }
        public String PManagerName { get { return this.ManagerName; } }
    }
}
