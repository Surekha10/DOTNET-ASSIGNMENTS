﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_assignment2
{
    class order
    {
        public int Order_Id;
        public String Customer_Name;
        public String Item_Name;
        public int Item_qty;
        public int Item_price;

        public int sum()
        {
            return Item_price * Item_qty;
        }

    }
}
