﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_assignment2
{
    class Employee
    {
        private int EmployeeID;
        private String EmployeeName;
        private Double EmployeeSalary;
        private String EmployeeCity;

        public Employee(int EmployeeID, String EmployeeName, Double EmployeeSalary, String EmployeeCity)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeSalary = EmployeeSalary;
            this.EmployeeCity = EmployeeCity;
        }
        public String GetDetails()
        {
            return this.EmployeeID + " " + this.EmployeeName + " " + this.EmployeeCity;

        }
        public Double Getsalary(int Days)
        {
            return (this.EmployeeSalary / 30) * Days;
        }

    }
}
