﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_JaggedArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] jagged = new int[3][];
            jagged[0] = new int[2];
            jagged[1] = new int[4];
            jagged[2] = new int[3];

            jagged[0][0] = 80;
            jagged[0][1] = 90;

            jagged[1][0] = 88;
            jagged[1][1] = 67;
            jagged[1][2] = 56;
            jagged[1][3] = 87;

            jagged[2][0] = 65;
            jagged[2][1] = 45;
            jagged[2][2] = 99;

           foreach(int [] ar in jagged)
            {
                foreach(int a in ar)
                {
                    Console.WriteLine(a);
                }

                Console.WriteLine("*******");
            }
            Console.ReadLine();


        }
    }
}
