﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment3
{
    class Ebook :Book
    {
        private int SizeofBook;
        private String Format;
    
    public Ebook(int BookID, String BookTitle, String Author, int price, int pages, int Size, String Format):base(BookID,BookTitle,Author,price,pages)
        {
        this.SizeofBook = Size;
        this.Format = Format;
    }

    public int PSize { get { return this.SizeofBook; } }
    public String PFormat { get { return this.Format; } }    

    }
}

