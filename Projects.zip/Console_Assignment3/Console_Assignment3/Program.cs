﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter BookId:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter BookTitle:");
            String Title = Console.ReadLine();
            Console.WriteLine("Enter Author Of the book:");
            String Author = Console.ReadLine();
            Console.WriteLine("Enter Price of book:");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter No of Pages:");
            int pages = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter type of book");
            String type = Console.ReadLine();
          if (type == "book")
            {
                Book obj = new Book(id, Title, Author, price, pages);
                Console.WriteLine(obj.PBookID);
                Console.WriteLine(obj.PBookTitle);
                Console.WriteLine(obj.PAuthor);
                Console.WriteLine(obj.Pprice);
                Console.WriteLine(obj.PNumberofpages);

            }
          else
            {
                Console.WriteLine("Enter size of book");
                int size = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Format of book");
                string format = Console.ReadLine();

                Ebook obj1 = new Ebook(id, Title, Author, price,pages, size, format);
                Console.WriteLine(obj1.PBookID);
                Console.WriteLine(obj1.PBookTitle);
                Console.WriteLine(obj1.PAuthor);
                Console.WriteLine(obj1.Pprice);
                Console.WriteLine(obj1.PNumberofpages);
                Console.WriteLine(obj1.PSize);
                Console.WriteLine(obj1.PFormat);


                    
            }
            Console.ReadLine();
          
            /* Console.WriteLine("Enter the name of Customer:");
             string Customername = Console.ReadLine();
             Console.WriteLine("Enter ItemName:");
             string ItemName = Console.ReadLine();
             Console.WriteLine("Enter  ItemPrice:");
             int Itemprice = Convert.ToInt32(Console.ReadLine());
             Console.WriteLine("Enter ItemQuantity:");
             int ItemQuantity = Convert.ToInt32(Console.ReadLine());

             Order obj = new  Order(Customername, ItemName, Itemprice, ItemQuantity);
             int result = obj.GetOrderAmount();
             Console.WriteLine(result);
             Console.WriteLine(obj.porderID);
             Console.WriteLine(obj.PCustomerName);
             Console.WriteLine(obj.PItemName);
             Console.WriteLine(obj.PItemPrice);
             Console.WriteLine(obj.PItemQuantity);


             obj.PItemQuantity = 5;
             Console.WriteLine(obj.PItemQuantity);
             int result1 = obj.GetOrderAmount();
             Console.WriteLine(result1);
             Console.ReadLine();
             */





        }
    }
}
