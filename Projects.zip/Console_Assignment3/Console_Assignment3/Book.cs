﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment3
{
    class Book
    {
        private int BookID;
        private string BookTitle;
        private String Author;
        private int Price;
        private int Pages;
        
        public Book(int BookID, String BookTitle,String Author,int Price, int Pages)
        {
            this.BookID = BookID;
            this.BookTitle = BookTitle;
            this.Author = Author;
            this.Price = Price;
            this.Pages = Pages;
        }
        public int PBookID { get { return this.BookID; } }
        public String PBookTitle { get { return this.BookTitle; } }

        public String PAuthor { get { return this.Author; } }

        public int Pprice { get { return this.Price; } }

        public int PNumberofpages { get { return this.Pages; } }
  

    }
} 
