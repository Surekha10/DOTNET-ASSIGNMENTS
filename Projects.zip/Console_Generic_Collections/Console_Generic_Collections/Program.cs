﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, String> names = new Dictionary<int, string>();

            names.Add(100, "xyz");
            names.Add(101, "ABCD");

            foreach(KeyValuePair<int,string> Kv in names)
            {
                Console.WriteLine("key :" + Kv.Key + " " + "Value :" + Kv.Value);
            }

            foreach(int key in names.Keys)
            {
                Console.WriteLine("Only key :" + key);

            }

            foreach(String value in names.Values)
            {
                Console.WriteLine("Only Value :" + value);
            }
                

          

            Console.WriteLine(names.Count);

            string s1 = names[100];

            Console.WriteLine(s1);

            if(names.ContainsKey(100))
            {
                Console.WriteLine(names[100]);
            }





          /*
            List<int> Marks = new List<int>();
            Marks.Add(100);
            Marks.Add(200);
            Marks.Add(300);

            foreach(var m in Marks)
            {
                Console.WriteLine();
            }

            Console.WriteLine(Marks.Count);

            bool Status = Marks.Contains(100);



            int x = Marks[1];

            Console.WriteLine(x);

            Marks.Remove(200);

            Console.WriteLine(Marks.Count);

            x = Marks[1];

            Console.WriteLine(x);

            foreach(var m in Marks)
            {
                Console.WriteLine(m);
            }

            */







            /*
            Test obj = new Test();

            int x = obj.GetData<int>(200);

            Console.WriteLine(x);

            double d = obj.GetData<double>(22.2);
            Console.WriteLine(d);

            String str = obj.GetData<String>("Hello");
            Console.WriteLine(str);
            */
            Console.ReadLine();
        }
    }
}
