﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overridding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter EmployeeName");
            String Name = Console.ReadLine();
            Console.WriteLine("Enter MonthlySalary");
            double Salary = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Type Of Employee");
            String Type = Console.ReadLine();


            Employee obj = null;

           if(Type=="Normal")
            {
                obj = new Employee(Name, Salary);
            }
           else if (Type == "Contract")
            {
                obj = new Employee_Contract(Name, Salary);
            }
            else if (Type == "Trainee")
            {
                obj = new Trainee(Name, Salary);
            }


            if (obj !=null)
           {
                Console.WriteLine(obj.PEmployeeID);
                Console.WriteLine(obj.PEmployeeName);
                Console.WriteLine(obj.PMonthlySalary);

                String Details = obj.GetDetails();
                Console.WriteLine(Details);
                String Work = obj.GetWork();
                Console.WriteLine(Work);

                Console.WriteLine("Enter No Of Days");
                int Days = Convert.ToInt32(Console.ReadLine());

                double salary = obj.GetSalary(Days);
                Console.WriteLine("Salary:" + Salary);
            }
            Console.ReadLine();


     
        }
    }
}
