﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Salary_Library;

namespace Console_Call_DLL
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter No Of Days:");
            int Days = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Per Day Salary:");
            int Per_Day_Salary = Convert.ToInt32(Console.ReadLine());

            Salary_Class obj = new Salary_Class();

            int total = obj.GetSalary(Days, Per_Day_Salary);

            Console.WriteLine("Salary :" + total);

            Console.ReadLine();



        }
    }
}
