﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract
{
   abstract class Account
    {
        private int AccountID;
        private String CustomerName;
        protected int AccountBalance;
        private static int count = 1000;

        public Account(String  CustomerName, int AccountBalance)
        {
            this.AccountID = Account.count++;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;
            Console.WriteLine("Account Abstarct Class Constructor");
        }

        public int GetBalance()
        {
            return this.AccountBalance;
        }

        public void StopPayment()
        {
            Console.WriteLine("Stop Paymnet Logic...");
        }

        public abstract void Deposit(int Amt);
        public abstract void WithDraw(int Amt);

        public int PAccountID { get { return this.AccountID; } }

        public String PCustomerName { get { return this.CustomerName; } }
        
    }
}
