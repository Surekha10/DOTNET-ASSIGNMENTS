﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Salary_Library
{
    public class Salary_Class
    {
        public int GetSalary(int Days,int per_day_Salary)
        {
            return Days * per_day_Salary +2000;
        }
    }
}
