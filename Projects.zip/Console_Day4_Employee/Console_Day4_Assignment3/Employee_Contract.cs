﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment3
{
    class Employee_Contract :Employee
    {
        public Employee_Contract(String EmployeeName, double MonthlySalary)
           : base(EmployeeName, MonthlySalary)
        {

        }

        public override double GetSalary(int Days)
        {
            double total = (this.PMonthlySalary / 30) * Days;
            return total;
        }
    }
}
