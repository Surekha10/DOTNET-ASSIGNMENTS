﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment3
{
    class Employee
    {
        private int EmployeeID;
        private String EmployeeName;
        private double MonthlySalary;
        private static int count = 1000;
        public Employee(String EmployeeName, double MonthlySalary)
        {
            this.EmployeeID = ++Employee.count;
            this.EmployeeName = EmployeeName;
            this.MonthlySalary = MonthlySalary;
        }

        public int PEmployeeID { get { return this.EmployeeID; } }
        public String PEmployeeName { get { return this.EmployeeName; } }

        public double PMonthlySalary { get { return this.MonthlySalary; } }

        public String GetDetails()
        {
            return this.EmployeeID + " " + this.EmployeeName;

        }
        public String GetWork()
        {
            return "Dotnet Developer";
        }

        public virtual double GetSalary(int Days)
        {
            int Bonus = 200;
            int TDS = 800;
            Double total = (this.MonthlySalary / 30) * Days + Bonus - TDS;
            return total;
        }
    }
}
