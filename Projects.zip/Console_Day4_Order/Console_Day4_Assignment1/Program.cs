﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the OrderID:");
            int ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter CustomerName:");
            String Name = Console.ReadLine();
            Console.WriteLine("Enter ItemQuantity:");
            int Quantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter ItemPrice:");
            int Price = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Type of Order:");
            String Type =Console.ReadLine();

            Order obj = null;

            if(Type =="Order")
            {
                obj =  new Order(ID, Name, Quantity, Price);
               
            }
            else if (Type == "Overseas")
            {
                obj = new Overseas (ID, Name, Quantity, Price);
            }

            if (obj != null)
            {

                Console.WriteLine(obj.pOrderID);
                Console.WriteLine(obj.PCustomerName);
                int Result = obj.GetOrderValue();
                Console.WriteLine(Result);
            }
            Console.ReadLine();


        }
    }
}
