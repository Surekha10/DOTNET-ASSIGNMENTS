﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment1
{
    class Overseas :Order
    {
        public Overseas(int OrderID,String CustomerName,int ItemQuantity,int ItemPrice)
            :base(OrderID,CustomerName,ItemQuantity,ItemPrice)
        {

        }

        public  override int GetOrderValue()
        { 
      
            int result;
            result = (PItemPrice * PItemQuantity) * 10 / 100;
            result = result + (PItemPrice * PItemQuantity);
            return result;
        }
    }
}
