﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment1
{
    class Order
    {
        private int OrderID;
        private String CustomerName;
        private int ItemQuantity;
        private int ItemPrice;
        
        public Order(int OrderID, String CustomerName, int ItemQuantity, int ItemPrice)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
        }

        public int pOrderID { get { return this.OrderID; } }

        public String PCustomerName {  get { return this.CustomerName; } }

        public int PItemQuantity { get { return this.ItemQuantity; } }

        public int PItemPrice { get { return this.ItemPrice; } }

        public virtual int GetOrderValue()
        {
            return PItemPrice * PItemQuantity;
        }

      
            

    }
}
