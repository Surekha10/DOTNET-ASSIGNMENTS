﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Employee ID:");
            int EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name:");
            String EmployeeName = Console.ReadLine();
            Console.WriteLine("Enter Employee City:");
            String EmployeeCity = Console.ReadLine();
            Employee obj = new Employee(EmployeeID, EmployeeName, EmployeeCity);
            Console.WriteLine(obj.pEmployeeId);
            Console.WriteLine(obj.pEmployeeName);
            Console.WriteLine(obj.pEmployeecity);
            Console.ReadLine();


        }

    }
    }



