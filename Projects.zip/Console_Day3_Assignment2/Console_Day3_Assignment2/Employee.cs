﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment2
{
    class Employee
    {
        private int EmployeeId;
        private String EmployeeName;
        private String EmployeeCity;

        public Employee(int EmployeeId, String EmployeeName,String EmployeeCity)
        {
            this.EmployeeId = EmployeeId;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            Console.WriteLine("Employee Object Constructor");

        }
        public int pEmployeeId
        {
            get { return this.EmployeeId; }
        }
        public String pEmployeeName
        {
            get
            {
                return this.EmployeeName;
            }
        }
        public String pEmployeecity
        {
            get {
                return this.EmployeeCity;
            }
        }



    }
}
        

    

