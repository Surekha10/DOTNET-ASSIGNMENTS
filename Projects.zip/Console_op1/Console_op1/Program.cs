﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_op1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number 1 :");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Number 2 :");
            int n2 = Convert.ToInt32(Console.ReadLine());

            calculator obj = new calculator();
            obj.Number1 = n1;
            obj.Number2 = n2;

            int result = obj.Sum();
            Console.WriteLine(result);
            result = obj.subtract();
            Console.WriteLine(result);
            Console.ReadLine();




        }
    }
}
