﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Enter Customer Name:");
            String Name = Console.ReadLine();
            Console.WriteLine("Enter Account Balance:");
            int Balance = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Account Type:");
            String Type = Console.ReadLine();

            Account obj = null;

            if (Type == "Saving")
            {
                obj = new Saving(Name, Balance);
            }
            else if (Type == "Current")
            {
                obj = new Current(Name, Balance);
            }
            if (obj != null)
            {
                Console.WriteLine(obj.PAccountID);
                Console.WriteLine(obj.PCustomerName);
                int balance = obj.GetBalance();
                Console.WriteLine("Balance:" + balance);

                Console.WriteLine("Enter an Amount to Deposit:");
                int Amount = Convert.ToInt32(Console.ReadLine());

                obj.Deposit(Amount);

                Balance = obj.GetBalance();
                Console.WriteLine("Balance:" + Balance);

                Console.WriteLine("Enter the Amount to WithDraw:");
                Amount = Convert.ToInt32(Console.ReadLine());
                obj.WithDraw(Amount);

                Balance = obj.GetBalance();
                Console.WriteLine("Balance:" + Balance);
                obj.StopPayment();
            }
            Console.ReadLine();

        }
    }
    }

