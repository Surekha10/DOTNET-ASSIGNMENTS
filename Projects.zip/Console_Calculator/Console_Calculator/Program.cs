﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter n1 Value");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter n2 Value");
            int n2 = Convert.ToInt32(Console.ReadLine());

            Calculator_Library_1.Class1 obj = new Calculator_Library_1.Class1();

            int sum = obj.GetSum(n1, n2);
            Console.WriteLine("sum:" + sum);

            int Multiply = obj.GetMultiply(n1, n2);
            Console.WriteLine("Multiply:" + Multiply);

            int Divide = obj.GetDivide(n1, n2);
            Console.WriteLine("Divide:" + Divide);

            int Substract = obj.GetSubstract(n1, n2);
            Console.WriteLine("Substract:" + Substract);

            Console.ReadLine();

        }
    }
}
