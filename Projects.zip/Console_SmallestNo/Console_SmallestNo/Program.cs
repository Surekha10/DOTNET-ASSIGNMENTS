﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_SmallestNo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[10];
            Console.WriteLine("Enter the array element to be sorted:");

            for(int i=0;i<10; i++)
            {
                array[i] = Convert.ToInt32(Console.ReadLine());
            }
            int Smallest = array[0];
             
           for(int i=0; i<10;i++)
            {
                if(array[i] < Smallest)
                {
                    Smallest = array[i];
                }

            }
            Console.WriteLine("Smallest:" + Smallest);
            Console.ReadLine();
        }
    }
}
