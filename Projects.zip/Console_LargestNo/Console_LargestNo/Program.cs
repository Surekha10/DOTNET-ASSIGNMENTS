﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_LargestNo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[10];
            Console.WriteLine("Enter the array Elements to be sorted");

            for(int i=0;i<10; i++)
            {
                array[i] = Convert.ToInt32(Console.ReadLine());
            }
            int Largest = array[0];

            for(int i=0;i<10;i++)
            {
                if(array[i]> Largest)
                {
                    Largest = array[i];
                }
            }

            Console.WriteLine("Largest:" + Largest);
            Console.ReadLine();
                
        }
    }
}
