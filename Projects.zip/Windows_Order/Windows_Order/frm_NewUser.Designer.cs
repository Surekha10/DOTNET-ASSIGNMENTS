﻿namespace Windows_Order
{
    partial class frm_NewUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_LoginID = new System.Windows.Forms.Label();
            this.lbl_CustomerName = new System.Windows.Forms.Label();
            this.lbl_CustomerCity = new System.Windows.Forms.Label();
            this.lbl_CustomerGender = new System.Windows.Forms.Label();
            this.txt_LoginID = new System.Windows.Forms.TextBox();
            this.txt_CustomerName = new System.Windows.Forms.TextBox();
            this.cmp_City = new System.Windows.Forms.ComboBox();
            this.rdb_Male = new System.Windows.Forms.RadioButton();
            this.rdb_Female = new System.Windows.Forms.RadioButton();
            this.btn_Login = new System.Windows.Forms.Button();
            this.btn_NewUser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_LoginID
            // 
            this.lbl_LoginID.AutoSize = true;
            this.lbl_LoginID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LoginID.Location = new System.Drawing.Point(56, 65);
            this.lbl_LoginID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_LoginID.Name = "lbl_LoginID";
            this.lbl_LoginID.Size = new System.Drawing.Size(110, 29);
            this.lbl_LoginID.TabIndex = 0;
            this.lbl_LoginID.Text = "LoginID:";
            // 
            // lbl_CustomerName
            // 
            this.lbl_CustomerName.AutoSize = true;
            this.lbl_CustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerName.Location = new System.Drawing.Point(61, 136);
            this.lbl_CustomerName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_CustomerName.Name = "lbl_CustomerName";
            this.lbl_CustomerName.Size = new System.Drawing.Size(201, 29);
            this.lbl_CustomerName.TabIndex = 1;
            this.lbl_CustomerName.Text = "CustomerName:";
            this.lbl_CustomerName.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_CustomerCity
            // 
            this.lbl_CustomerCity.AutoSize = true;
            this.lbl_CustomerCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerCity.Location = new System.Drawing.Point(67, 214);
            this.lbl_CustomerCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_CustomerCity.Name = "lbl_CustomerCity";
            this.lbl_CustomerCity.Size = new System.Drawing.Size(176, 29);
            this.lbl_CustomerCity.TabIndex = 2;
            this.lbl_CustomerCity.Text = "CustomerCity:";
            // 
            // lbl_CustomerGender
            // 
            this.lbl_CustomerGender.AutoSize = true;
            this.lbl_CustomerGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerGender.Location = new System.Drawing.Point(67, 286);
            this.lbl_CustomerGender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_CustomerGender.Name = "lbl_CustomerGender";
            this.lbl_CustomerGender.Size = new System.Drawing.Size(219, 29);
            this.lbl_CustomerGender.TabIndex = 3;
            this.lbl_CustomerGender.Text = "CustomerGender:";
            // 
            // txt_LoginID
            // 
            this.txt_LoginID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LoginID.Location = new System.Drawing.Point(249, 65);
            this.txt_LoginID.Margin = new System.Windows.Forms.Padding(4);
            this.txt_LoginID.Name = "txt_LoginID";
            this.txt_LoginID.Size = new System.Drawing.Size(313, 35);
            this.txt_LoginID.TabIndex = 4;
            // 
            // txt_CustomerName
            // 
            this.txt_CustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerName.Location = new System.Drawing.Point(249, 136);
            this.txt_CustomerName.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CustomerName.Name = "txt_CustomerName";
            this.txt_CustomerName.Size = new System.Drawing.Size(313, 35);
            this.txt_CustomerName.TabIndex = 5;
            // 
            // cmp_City
            // 
            this.cmp_City.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmp_City.FormattingEnabled = true;
            this.cmp_City.Location = new System.Drawing.Point(249, 202);
            this.cmp_City.Margin = new System.Windows.Forms.Padding(4);
            this.cmp_City.Name = "cmp_City";
            this.cmp_City.Size = new System.Drawing.Size(341, 37);
            this.cmp_City.TabIndex = 6;
            // 
            // rdb_Male
            // 
            this.rdb_Male.AutoSize = true;
            this.rdb_Male.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_Male.Location = new System.Drawing.Point(294, 286);
            this.rdb_Male.Margin = new System.Windows.Forms.Padding(4);
            this.rdb_Male.Name = "rdb_Male";
            this.rdb_Male.Size = new System.Drawing.Size(95, 33);
            this.rdb_Male.TabIndex = 7;
            this.rdb_Male.TabStop = true;
            this.rdb_Male.Text = "Male";
            this.rdb_Male.UseVisualStyleBackColor = true;
            // 
            // rdb_Female
            // 
            this.rdb_Female.AutoSize = true;
            this.rdb_Female.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_Female.Location = new System.Drawing.Point(503, 286);
            this.rdb_Female.Margin = new System.Windows.Forms.Padding(4);
            this.rdb_Female.Name = "rdb_Female";
            this.rdb_Female.Size = new System.Drawing.Size(126, 33);
            this.rdb_Female.TabIndex = 8;
            this.rdb_Female.TabStop = true;
            this.rdb_Female.Text = "Female";
            this.rdb_Female.UseVisualStyleBackColor = true;
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(107, 358);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(206, 37);
            this.btn_Login.TabIndex = 9;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // btn_NewUser
            // 
            this.btn_NewUser.Location = new System.Drawing.Point(440, 363);
            this.btn_NewUser.Name = "btn_NewUser";
            this.btn_NewUser.Size = new System.Drawing.Size(163, 32);
            this.btn_NewUser.TabIndex = 10;
            this.btn_NewUser.Text = "NewUser";
            this.btn_NewUser.UseVisualStyleBackColor = true;
            this.btn_NewUser.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // frm_NewUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 438);
            this.Controls.Add(this.btn_NewUser);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.rdb_Female);
            this.Controls.Add(this.rdb_Male);
            this.Controls.Add(this.cmp_City);
            this.Controls.Add(this.txt_CustomerName);
            this.Controls.Add(this.txt_LoginID);
            this.Controls.Add(this.lbl_CustomerGender);
            this.Controls.Add(this.lbl_CustomerCity);
            this.Controls.Add(this.lbl_CustomerName);
            this.Controls.Add(this.lbl_LoginID);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_NewUser";
            this.Text = "frm_NewUser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_LoginID;
        private System.Windows.Forms.Label lbl_CustomerName;
        private System.Windows.Forms.Label lbl_CustomerCity;
        private System.Windows.Forms.Label lbl_CustomerGender;
        private System.Windows.Forms.TextBox txt_LoginID;
        private System.Windows.Forms.TextBox txt_CustomerName;
        private System.Windows.Forms.ComboBox cmp_City;
        private System.Windows.Forms.RadioButton rdb_Male;
        private System.Windows.Forms.RadioButton rdb_Female;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Button btn_NewUser;
    }
}