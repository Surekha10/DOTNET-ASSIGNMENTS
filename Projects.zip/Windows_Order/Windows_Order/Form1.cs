﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void btn_Login_Click(object sender, EventArgs e)
        {

            if (txt_Login.Text == String.Empty)
            {
                MessageBox.Show("Enter LoginID");
            }
            else if (txt_Password.Text == string.Empty)
            {
                MessageBox.Show("Enter Password:");
            }
            else
            {

                int LoginID = Convert.ToInt32(txt_Password.Text);
                String Password = lbl_Password.Text;


                if (LoginID == 1002 && Password == "pass@123")
                {
                    MessageBox.Show("Valid User");
                    
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }


            }
        }

        private void btn_NewUser_Click(object sender, EventArgs e)
        {
            frm_NewUser obj = new frm_NewUser();
            obj.Show();

        }
    }
}