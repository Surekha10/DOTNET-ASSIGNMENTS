﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductA objA = new ProductA(1, "OnePlus", 35000);
            ProductB objB = new ProductB(2, "Dell Laptop", 50000);

            Console.WriteLine("Enter Your Name:");
            String CustomerName = Console.ReadLine();

            Order ord = new Order(CustomerName);

            Console.WriteLine("Enter the ProductName:");
            String ProductName = Console.ReadLine();

            if(ProductName=="OnePlus")
            {
                ord.AddProduct(objA, 1);
            }
            else
            {
                ord.AddProduct(objB, 2);
            }

            Console.WriteLine(ord.POrderid);
            Console.WriteLine(ord.PCustomerName);
            int OrderValue = ord.GetOrderValue();
            Console.WriteLine("Total Order Value :" + OrderValue);

            Console.ReadLine();
        }
    }
}
