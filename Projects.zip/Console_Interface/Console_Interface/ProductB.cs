﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class ProductB : IOrderProduct
    {
        private int ProId;
        private String ProName;
        private int Proprice;
        public ProductB(int ProId,String ProName, int Proprice)
        {
            this.ProId = ProId;
            this.ProName = ProName;
            this.Proprice = Proprice;
        }

        public int GetPrice()
        {
            return this.Proprice;

        }

        public int GetProductID()
        {
            return this.ProId;
        }
    }
}
