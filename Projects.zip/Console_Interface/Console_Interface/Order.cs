﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Order
    {
        private int OrderId;
        private String CustomerName;
        private IOrderProduct proobj;
        private static int count = 1000;
        private int Quantity;

        public Order(String CustomerName)
        {
            this.OrderId = ++Order.count;
            this.CustomerName = CustomerName;
        }

        public void AddProduct(IOrderProduct p , int Quantity)
        {
            this.proobj = p;
            this.Quantity = Quantity;
            Console.WriteLine("Product Added in the Order");
            int id = proobj.GetProductID();
            int price = proobj.GetPrice();
            Console.WriteLine("product Details :" + id + ",Price : " + price);
     
   
        }
        public int GetOrderValue()
        {
            return this.proobj.GetPrice() * this.Quantity;

        }

        public int POrderid { get { return this.OrderId; } }

        public String PCustomerName { get { return this.CustomerName; } }
    }
}
