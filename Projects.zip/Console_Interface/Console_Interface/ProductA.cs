﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class ProductA : IOrderProduct
    {
        private int ProductId;
        private String ProductName;
        private int ProductPrice;
            public ProductA(int ProductId, String ProductName, int ProductPrice)
        {
            this.ProductId = ProductId;
            this.ProductName = ProductName;
            this.ProductPrice = ProductPrice;
        }

        public int GetPrice()
        {
            return this.ProductPrice;
        }

        public int GetProductID()
        {
            return this.ProductId;
        }
    }
}
