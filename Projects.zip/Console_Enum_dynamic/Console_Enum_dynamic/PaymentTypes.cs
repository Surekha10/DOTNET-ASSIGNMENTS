﻿enum PaymentTypes
{
    COD,Cash=3,Card,NetBanking=0
}