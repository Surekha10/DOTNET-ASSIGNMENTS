﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Enum_dynamic
{
    class Text
    {
        public void Call(PaymentTypes Type)
        {
            Console.WriteLine(Type.ToString());
            Console.WriteLine(Convert.ToInt32(Type));
            if(Type==PaymentTypes.Card)
            {
                Console.WriteLine("Card Payment");
            }
        }
    }
}
