﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Enum_dynamic
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;


            var i = 100;
            var a = "abc";

            string str = a.ToUpper();

            dynamic d1 = 100;
            dynamic d2 = "abc";

            Text t = new Text();
            t.Call(PaymentTypes.Card);
            t.Call(PaymentTypes.NetBanking);
            t.Call(PaymentTypes.COD);

            Console.ReadLine();
        }
    }
}
