﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1_Basics
{
    class Program
    {
        static void Main(string[] args)
        {








            //int number1;
            //int number2;
            //Console.WriteLine("Enter Number 1 :");
            //number1 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Enter Number 2 :");
            //number2 = Convert.ToInt32(Console.ReadLine());

            //int total = number1 + number2;

            //Console.WriteLine("Total :" + total);
            
            
            
            
            
            
            
            //string loginid;
            //string password;
            //Console.WriteLine(" Enter Login Id :");
            //loginid = Console.ReadLine();

            //Console.WriteLine("Enter Password:");
            //password = Console.ReadLine();

            //if(loginid=="Admin" && password=="pass@123")
            //{
            //    Console.WriteLine("Valid User");
            //}
            //else
            //{
            //    Console.WriteLine("Invalid User");
            //}
            Console.ReadLine();
        }
    }
}
