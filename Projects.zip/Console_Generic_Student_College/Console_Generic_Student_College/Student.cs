﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Student_College
{
    class Student
    {
        private int StudentID;
        private string StudentName;
        private string StudentCity;
        private static int Count = 1000;

        public Student(String StudentName,String StudentCity)
        {
            this.StudentID = ++Count;
            this.StudentName = StudentName;
            this.StudentCity = StudentCity;
        }
        public int PStudentID { get { return this.StudentID; } }

        public String PStudentName { get { return this.StudentName; } }

        public String PStudentCity { get { return this.StudentCity; }
                     set { this.StudentCity = value; } }

        public void LeaveRequest(String Reason)
        {
            Console.WriteLine("Leave Request: StudentID:" 
                    + this.StudentID + " , Reason :" + Reason);
                     
        }
    }
}
