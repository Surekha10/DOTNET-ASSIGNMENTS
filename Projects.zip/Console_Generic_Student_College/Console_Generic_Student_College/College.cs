﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Student_College
{
    class College
    { 
        private int  CollegeID;
        private String CollegeName;
        private List<Student> Studentlist = new List<Student>();

        public College(int CollegeID, String CollegeName)
        {
            this.CollegeID = CollegeID;
            this.CollegeName = CollegeName;
        }
        public int PCollegeID { get { return this.CollegeID; } }
        public String PCollegeName { get { return this.CollegeName; } }

        public void AddStudent(Student obj)
        {
            Studentlist.Add(obj);
            Console.WriteLine("Student Added Successfully....");
        }

        public bool RemoveStudent(int ID)
        {
            foreach(Student s in this.Studentlist)
            {
                if(s.PStudentID==ID)
                {
                    this.Studentlist.Remove(s);
                    return true;
                }
            }
            return false;
        }

        public Student FindStudent(int ID)
        {
            foreach(Student s in this.Studentlist)
            {
                if(s.PStudentID==ID)
                {
                    return s;
                }
            }
            return null;
        }
        public void ShowAll()
        {
            foreach(Student s in this.Studentlist)
            {
                Console.WriteLine(s.PStudentID + " " + s.PStudentName);
            }
        }

    }
}
