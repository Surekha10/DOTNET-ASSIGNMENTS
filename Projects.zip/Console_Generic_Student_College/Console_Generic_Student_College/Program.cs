﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Student_College
{
    class Program
    {
        static void Main(string[] args)
        {
            College PathFront = new College(1001, "pathFront,BGL");
            Console.WriteLine(PathFront.PCollegeID + " " + PathFront.PCollegeName);

            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1-Add,2-Find,3-Remove,4-Show,5-Request Leave, 6-Exit");
                int opt = Convert.ToInt32(Console.ReadLine());

                switch(opt)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter StudentName :");
                            String StudentName = Console.ReadLine();
                            Console.WriteLine("Enter StudentCity :");
                            String StudentCity = Console.ReadLine();

                            Student obj = new Student(StudentName, StudentCity);
                            PathFront.AddStudent(obj);

                            Console.WriteLine("Your StudentID :" + obj.PStudentID);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter StudentID:");
                            int ID = Convert.ToInt32(Console.ReadLine());
                            Student obj = PathFront.FindStudent(ID);
                            if(obj!=null)
                            {
                                Console.WriteLine("Student Details:");
                                Console.WriteLine(obj.PStudentID + " " + obj.PStudentName +
                                    " " + obj.PStudentCity);
                            }
                            else
                            {
                                Console.WriteLine("Student Not Found");
                            }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Enter StudentID:");
                            int ID = Convert.ToInt32(Console.ReadLine());

                            bool Status = PathFront.RemoveStudent(ID);
                            if(Status==true)
                            {
                                Console.WriteLine("Student Removed");
                            }
                            else
                            {
                                Console.WriteLine("Student Not Found");
                            }

                            break;
                        }
                    case 4:
                        {
                            PathFront.ShowAll();
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Enter StudentID:");
                            int ID = Convert.ToInt32(Console.ReadLine());
                            Student obj = PathFront.FindStudent(ID);
                            if(obj!=null)
                            {
                                Console.WriteLine("Enter the Reason:");
                                string Reason = Console.ReadLine();
                                obj.LeaveRequest(Reason);
                            }
                            else
                            {
                                Console.WriteLine("Wrong StudentID:");
                            }

                            break;
                        }
                    case 6:
                        {
                            flag = false;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("you have entered Wrong Option");
                            break;
                        }
                }
            }
        }
    }
}
