﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Inheritance
{
    class Customer_Online: Customer
    {
        private String PaymentType;
        private String HomeAddress;

        public Customer_Online(String CustomerName,String CustomerEmail,String PaymentType,String HomeAddress):base(CustomerName,CustomerEmail)
        {
            this.PaymentType = PaymentType;
            this.HomeAddress = HomeAddress;

            Console.WriteLine("Customer Online Object Constructor");
        }
         
        public String PPaymentType { get { return this.PaymentType; } }   
        public String pHomeAddress { get { return this.HomeAddress; } }

    }
}
