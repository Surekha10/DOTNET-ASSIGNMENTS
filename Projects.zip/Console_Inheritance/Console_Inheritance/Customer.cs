﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Inheritance
{
    class Customer
    {
        private int CustomerID;
        private String CustomerName;
        private String CustomerEmail;

        private static int count = 1000;
        public Customer(String CustomerName, String CustomerEmail)
            {
            Customer.count++;
            this.CustomerID = Customer.count;
            this.CustomerName = CustomerName;
            this.CustomerEmail = CustomerEmail;

        }
         public int pcustomerID
        {
            get
            {
                return this.CustomerID;
            }

        }
            
         public String PcustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }   

        public String PcustomerEmail
        {
            get
            {
                return this.CustomerEmail;
            }
        }






    }
}
