﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter CustomerName:");
            String CustomerName = Console.ReadLine();

            Console.WriteLine("Enter CustomerEmail:");
            String CustomerEmail = Console.ReadLine();

            Console.WriteLine("Enter CustomerType:");

            String CustomerType = Console.ReadLine();

            if(CustomerType!="Online")
            {
                Customer obj = new Customer(CustomerName, CustomerEmail);
                Console.WriteLine(obj.pcustomerID);
                Console.WriteLine(obj.PcustomerName);
                Console.WriteLine(obj.PcustomerEmail);
            }

            else
            {
                Console.WriteLine("Enter Customer Payment Type:");
                String PaymentType = Console.ReadLine();
                Console.WriteLine("Enter Customer Customer Home Address:");
                String CustomerHomeAdress = Console.ReadLine();
                Customer_Online obj = new Customer_Online(CustomerName, CustomerEmail, PaymentType,CustomerHomeAdress);
                Console.WriteLine(obj.pcustomerID);
                Console.WriteLine(obj.pcustomerID);
                Console.WriteLine(obj.PcustomerEmail);
                Console.WriteLine(obj.PPaymentType);
                Console.WriteLine(obj.pHomeAddress);
            }
            
            
            Console.ReadLine();




        }
    }
}
