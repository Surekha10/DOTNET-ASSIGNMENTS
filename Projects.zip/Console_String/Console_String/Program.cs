﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_String
{
    class Program
    {
        static void Main(string[] args)
        {
            String s1 = "a";
            char[] c = { 'a' };
            Object obj = new String(c);
            Console.WriteLine(s1 == obj);
            Console.WriteLine(s1.Equals(obj));

            String name = "ABCD";
            char[] ch = name.ToCharArray();

            for (int i=0;i<ch.Length;i++)
            {
                Console.WriteLine(ch[i]);
                int x = Convert.ToInt32(ch[i]);
                Console.WriteLine(x);
                //ch[i] = 'x';

            }

            String str = new string(ch);
            Console.WriteLine(str);

            String x1 = str.Substring(2);
            String x2 = str.Substring(1, 2); 

            Console.WriteLine(x1); //CD
            Console.WriteLine(x2); //BC
                


            Console.ReadLine();




        }
    }
}
