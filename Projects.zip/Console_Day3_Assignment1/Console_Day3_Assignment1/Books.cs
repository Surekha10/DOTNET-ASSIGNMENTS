﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment1
{
    class Books
    {
        private int BooksID;
        private string BooksTitle;
        private string Author;
        private int Price;
        private int Pages;
        public Books(int BooksID, string BooksTitle, string Author, int Price, int Pages)
        {
            this.BooksID = BooksID;
            this.BooksTitle = BooksTitle;
            this.Author = Author;
            this.Price = Price;
            this.Pages = Pages;
        }
        public int PBooksID
        {
            get
            {
                return this.BooksID;
            }
        }
        public string PBooksTitle
        {
            get
            {
                return this.BooksTitle;
            }
        }

        public string PAuthor
        {
            get
            {
                return this.Author;
            }
        }

        public int Pprice
        {
            get
            {
                return this.Price;
            }
        }

        public int PNumberofpages
        {
            get
            {
                return this.Pages;
            }
        }
    }
}
