﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter BookId:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter BookTitle:");
            String Title = Console.ReadLine();
            Console.WriteLine("Enter Author Of the book:");
            String Author = Console.ReadLine();
            Console.WriteLine("Enter Price of book:");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter No of Pages:");
            int pages = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter type of book");
            String type = Console.ReadLine();
            if (type == "book")
            {
                Books obj = new Books(id, Title, Author, price, pages);
                Console.WriteLine(obj.PBooksID);
                Console.WriteLine(obj.PBooksTitle);
                Console.WriteLine(obj.PAuthor);
                Console.WriteLine(obj.Pprice);
                Console.WriteLine(obj.PNumberofpages);

            }
            else
            {
                Console.WriteLine("Enter size of book");
                int size = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Format of book");
                string format = Console.ReadLine();

                Ebooks obj1 = new Ebooks(id, Title, Author, price, pages, size, format);
                Console.WriteLine(obj1.PBooksID);
                Console.WriteLine(obj1.PBooksTitle);
                Console.WriteLine(obj1.PAuthor);
                Console.WriteLine(obj1.Pprice);
                Console.WriteLine(obj1.PNumberofpages);
                Console.WriteLine(obj1.PSize);
                Console.WriteLine(obj1.PFormat);

            }
            Console.ReadLine();
        }
    }
}
