﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment1
{
    class Ebooks :Books
    {
        private int SizeofBook;
        private String Format;

        public Ebooks(int BookID, String BookTitle, String Author, int price, int pages, int Size, String Format):base(BookID,BookTitle,Author,price,pages)
        {
            this.SizeofBook = Size;
            this.Format = Format;
        }

        public int PSize { get { return this.SizeofBook; } }
        public String PFormat { get { return this.Format; } }

    }
}
