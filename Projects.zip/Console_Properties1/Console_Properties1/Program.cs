﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Properties1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Test.Count);//0

            Test.Count = 100;
            Test t1 = new Test();

            Console.WriteLine(Test.Count);//101

            Test t2 = new Test();//102
            Test.Count = 200;

            Console.WriteLine(Test.Count);//200







            /*
            Console.WriteLine("Enter StudentID:");
            int ID = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter StudentName:");
            String Name = Console.ReadLine();

            Console.WriteLine("Enter StudentMarks:");
            int Marks= Convert.ToInt32(Console.ReadLine());

            Student obj = new Student(ID, Name, Marks);

            Console.WriteLine(obj.PstudentID);
            Console.WriteLine(obj.PstudentName);
            Console.WriteLine(obj.pstudentMarks);

            //obj.PstudentID = 1001;// ReadOnly
            obj.pstudentMarks = 200;

            Console.WriteLine(obj.pstudentMarks);
            obj.pstudentMarks = 90;

            Console.WriteLine(obj.pstudentMarks);
            */
            Console.ReadLine();




        }
    }
}
