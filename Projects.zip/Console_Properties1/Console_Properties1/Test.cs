﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Properties1
{
    class Test
    {
        public static int Count;//0

        public Test()
        {
            Test.Count++;
        }

        static Test()
        {
            Test.Count = 10;
        }

        public static void call()
        {

        }

           
    }
}
