﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Properties1
{
    class Student
    {
        private int StudentID;
        private String StudentName;
        private int StudentMarks;

        public Student(int StudentID, String StudentName, int StudentMarks)
        {
            this.StudentID = StudentID;
            this.StudentName = StudentName;
            this.StudentMarks = StudentMarks;
        }

        public int PstudentID
        {
            get
            {
                return this.StudentID;
            }
        }
        public String PstudentName
        {
            get
            {
                return this.StudentName;
            }
            set
            {
                this.StudentName = value;
            }

        }
        public int pstudentMarks
        {
            get
            {
                return this.StudentMarks;
            }
            set
            {
                if (value > 100 || value < 0)
                {
                    this.StudentMarks = 0;
                }
                else
                {
                    this.StudentMarks = value;
                }
               
            }

        }
    }
}
