﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment_Day1_Order
{
    class Order
    {
        public int Order_id;
        public String Customer_name;
        public String Item_name;
        public int Item_qty;
        public int Item_price;

        public int sum()
        {
            return (Item_price * Item_qty);
        }

    }
    
}
