﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment_Day1_Order
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Order id");
            int Orderid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter customer _name");
            string customer_name = Console.ReadLine();
            Console.WriteLine("Enter Item_name");
            string Item_name = Console.ReadLine();
            Console.WriteLine("enter price");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter qty");
            int n2 = Convert.ToInt32(Console.ReadLine());
            Order obj = new Order();
            obj.Item_price = n1;
            obj.Item_qty = n2;

            int result = obj.sum();
            Console.WriteLine(result);
            Console.ReadLine();




        }
    }
}
