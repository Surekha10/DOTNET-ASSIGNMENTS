﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Controls
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (txt_Loginid.Text == String.Empty) 
            {
                MessageBox.Show("Enter LoginID:");
            }

            else if (txt_Password.Text == String.Empty) 
            {
                MessageBox.Show("Enter Password:"); 
            }

            else
            {

                int LoginID = Convert.ToInt32(txt_Loginid.Text);
                String Password = txt_Password.Text;

                if(LoginID == 1001 && Password == "Pass@123")
                {
                    MessageBox.Show("Valid User");
                    frm_home obj = new frm_home();
                    obj.Show(); // open the form
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }
            }
        }

        private void NewUser_Click(object sender, EventArgs e)
        {
            frm_NewUser obj = new frm_NewUser();
            obj.Show();
        }

    }
}
