﻿namespace Win_Controls
{
    partial class frm_NewUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_LoginID = new System.Windows.Forms.Label();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.lbl_CustomerName = new System.Windows.Forms.Label();
            this.lbl_CustomerCity = new System.Windows.Forms.Label();
            this.lbl_CustomerGender = new System.Windows.Forms.Label();
            this.txt_LoginID = new System.Windows.Forms.TextBox();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.txt_Name = new System.Windows.Forms.TextBox();
            this.rdb_Male = new System.Windows.Forms.RadioButton();
            this.rdb_Female = new System.Windows.Forms.RadioButton();
            this.btn_NewUser = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.cmb_City = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_LoginID
            // 
            this.lbl_LoginID.AutoSize = true;
            this.lbl_LoginID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LoginID.Location = new System.Drawing.Point(67, 40);
            this.lbl_LoginID.Name = "lbl_LoginID";
            this.lbl_LoginID.Size = new System.Drawing.Size(110, 29);
            this.lbl_LoginID.TabIndex = 0;
            this.lbl_LoginID.Text = "LoginID:";
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Password.Location = new System.Drawing.Point(67, 95);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(135, 29);
            this.lbl_Password.TabIndex = 1;
            this.lbl_Password.Text = "Password:";
            // 
            // lbl_CustomerName
            // 
            this.lbl_CustomerName.AutoSize = true;
            this.lbl_CustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerName.Location = new System.Drawing.Point(71, 153);
            this.lbl_CustomerName.Name = "lbl_CustomerName";
            this.lbl_CustomerName.Size = new System.Drawing.Size(208, 29);
            this.lbl_CustomerName.TabIndex = 2;
            this.lbl_CustomerName.Text = "Customer Name:";
            // 
            // lbl_CustomerCity
            // 
            this.lbl_CustomerCity.AutoSize = true;
            this.lbl_CustomerCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerCity.Location = new System.Drawing.Point(75, 200);
            this.lbl_CustomerCity.Name = "lbl_CustomerCity";
            this.lbl_CustomerCity.Size = new System.Drawing.Size(183, 29);
            this.lbl_CustomerCity.TabIndex = 3;
            this.lbl_CustomerCity.Text = "Customer City:";
            // 
            // lbl_CustomerGender
            // 
            this.lbl_CustomerGender.AutoSize = true;
            this.lbl_CustomerGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerGender.Location = new System.Drawing.Point(77, 256);
            this.lbl_CustomerGender.Name = "lbl_CustomerGender";
            this.lbl_CustomerGender.Size = new System.Drawing.Size(226, 29);
            this.lbl_CustomerGender.TabIndex = 4;
            this.lbl_CustomerGender.Text = "Customer Gender:";
            // 
            // txt_LoginID
            // 
            this.txt_LoginID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LoginID.Location = new System.Drawing.Point(302, 51);
            this.txt_LoginID.Name = "txt_LoginID";
            this.txt_LoginID.Size = new System.Drawing.Size(266, 35);
            this.txt_LoginID.TabIndex = 5;
            // 
            // txt_Password
            // 
            this.txt_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Password.Location = new System.Drawing.Point(302, 92);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(266, 35);
            this.txt_Password.TabIndex = 6;
            // 
            // txt_Name
            // 
            this.txt_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Name.Location = new System.Drawing.Point(307, 147);
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.Size = new System.Drawing.Size(266, 35);
            this.txt_Name.TabIndex = 7;
            // 
            // rdb_Male
            // 
            this.rdb_Male.AutoSize = true;
            this.rdb_Male.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_Male.Location = new System.Drawing.Point(309, 252);
            this.rdb_Male.Name = "rdb_Male";
            this.rdb_Male.Size = new System.Drawing.Size(95, 33);
            this.rdb_Male.TabIndex = 11;
            this.rdb_Male.TabStop = true;
            this.rdb_Male.Text = "Male";
            this.rdb_Male.UseVisualStyleBackColor = true;
            // 
            // rdb_Female
            // 
            this.rdb_Female.AutoSize = true;
            this.rdb_Female.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_Female.Location = new System.Drawing.Point(426, 254);
            this.rdb_Female.Name = "rdb_Female";
            this.rdb_Female.Size = new System.Drawing.Size(126, 33);
            this.rdb_Female.TabIndex = 12;
            this.rdb_Female.TabStop = true;
            this.rdb_Female.Text = "Female";
            this.rdb_Female.UseVisualStyleBackColor = true;
            // 
            // btn_NewUser
            // 
            this.btn_NewUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewUser.Location = new System.Drawing.Point(72, 318);
            this.btn_NewUser.Name = "btn_NewUser";
            this.btn_NewUser.Size = new System.Drawing.Size(130, 40);
            this.btn_NewUser.TabIndex = 13;
            this.btn_NewUser.Text = "New User";
            this.btn_NewUser.UseVisualStyleBackColor = true;
            this.btn_NewUser.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Close.Location = new System.Drawing.Point(261, 318);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(154, 40);
            this.btn_Close.TabIndex = 14;
            this.btn_Close.Text = "Close";
            this.btn_Close.UseVisualStyleBackColor = true;
            this.btn_Close.Click += new System.EventHandler(this.button2_Click);
            // 
            // cmb_City
            // 
            this.cmb_City.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_City.FormattingEnabled = true;
            this.cmb_City.Location = new System.Drawing.Point(302, 192);
            this.cmb_City.Name = "cmb_City";
            this.cmb_City.Size = new System.Drawing.Size(287, 37);
            this.cmb_City.TabIndex = 15;
            this.cmb_City.SelectedIndexChanged += new System.EventHandler(this.cmb_City_SelectedIndexChanged);
            // 
            // frm_NewUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 412);
            this.Controls.Add(this.cmb_City);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_NewUser);
            this.Controls.Add(this.rdb_Female);
            this.Controls.Add(this.rdb_Male);
            this.Controls.Add(this.txt_Name);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.txt_LoginID);
            this.Controls.Add(this.lbl_CustomerGender);
            this.Controls.Add(this.lbl_CustomerCity);
            this.Controls.Add(this.lbl_CustomerName);
            this.Controls.Add(this.lbl_Password);
            this.Controls.Add(this.lbl_LoginID);
            this.Name = "frm_NewUser";
            this.Text = "Login ID:";
            this.Load += new System.EventHandler(this.lbl_name_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_LoginID;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.Label lbl_CustomerName;
        private System.Windows.Forms.Label lbl_CustomerCity;
        private System.Windows.Forms.Label lbl_CustomerGender;
        private System.Windows.Forms.TextBox txt_LoginID;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.TextBox txt_Name;
        private System.Windows.Forms.RadioButton rdb_Male;
        private System.Windows.Forms.RadioButton rdb_Female;
        private System.Windows.Forms.Button btn_NewUser;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.ComboBox cmb_City;
    }
}