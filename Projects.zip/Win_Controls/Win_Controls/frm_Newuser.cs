﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Controls
{
    public partial class frm_NewUser : Form
    {
        public frm_NewUser()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close(); // Closing the form
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txt_LoginID.Text == String.Empty)
            {
                MessageBox.Show("Enter LoginID:");
            }

            else if(txt_Password.Text == String.Empty)
            {
                MessageBox.Show("Enter Password:");
            }
             
           else if(txt_Name.Text == String.Empty)
            {
                MessageBox.Show("Enter Name:");
            }
            else if(cmb_City.Text == String.Empty)
            {
                MessageBox.Show("Select City:");
            }
            else if(rdb_Male.Checked == false && rdb_Female.Checked == false)
            {
                MessageBox.Show("Show Gender:");
            }

            else
            {
                int LoginID = Convert.ToInt32(txt_LoginID.Text);
                String Password = txt_Password.Text;
                String CustomerName = txt_Name.Text;
                String CustomerCity = cmb_City.Text;
                String CustomerGender = String.Empty;
                if(rdb_Male.Checked)
                { CustomerGender = "Male"; }
                else
                        { CustomerGender = "Female"; }
                MessageBox.Show("Customer Created");
            }
                
        }

        private void lbl_name_Load(object sender, EventArgs e)
        {
            cmb_City.Items.Add("BGL");
            cmb_City.Items.Add("Pune");
            cmb_City.Items.Add("HYd");
            cmb_City.Items.Add("Chennai");
        }

        private void cmb_City_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmb_City.Items.Add("BGL");
            cmb_City.Items.Add("HYD");
            cmb_City.Items.Add("PUNE");
            cmb_City.Items.Add("CHENNAI");
        }
    }
}
