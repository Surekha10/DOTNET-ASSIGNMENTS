﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Functions
{
    class Program
    {
        static void Main(string[] args)
        {
            x obj1 = new x();
            obj1.ca111();
            obj1.call2();

            Test obj = new Test();

            int a;

            obj.getdata(out a);

            Console.WriteLine(a);


            int t1 = obj.GetSum(10, 20);
            Console.WriteLine(t1);

            double d = obj.GetSum(22.3, 33.3);
            Console.WriteLine(d);

            int t2 = obj.GetSum("1", "2");
            Console.WriteLine(t2);

            int t3 = obj.GetSum(2, 3, 4);
            Console.WriteLine(t3);

            Console.ReadLine();







        }
    }
}
