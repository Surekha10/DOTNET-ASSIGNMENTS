﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Functions
{
    class Test
    {

        public void getdata( out int x )
        {
            x = 100;
        }
           
        public int GetSum(int n1, int n2)
        {
            return n1 + n2;
        }
      
        public  int GetSum(String s1, String s2)
        {
            int n1 = Convert.ToInt32(s1);
            int n2 = Convert.ToInt32(s2);
            return n1 + n2;
        }

        public int GetSum(int n1, int n2, int n3)
        {
            return n1 + n2 + n3;
        }
        public double GetSum(double d1,double d2)
        {
            return d1 + d2;
        }


    }
}
