﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Functions
{
    partial class x
    {
        public void call2()
        {

        }
    }
}
