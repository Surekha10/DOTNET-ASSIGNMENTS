﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_account
{
    class Account
    {
        private  readonly int AccountID;
        private String CustomerName;
        private int AccountBalance;

        public Account(int AccountID, String CustomerName, int AccountBalance)
            :this(AccountID,CustomerName)
        {
           
    
            this.AccountBalance = AccountBalance;
            Console.WriteLine("Account Construtor 2");

        }

        public Account(int AccountID,String CustomerName)
            {
            this.AccountID = AccountID;
            this.CustomerName = CustomerName;
            Console.WriteLine("Account Constructor 1");
        }


        public void Deposit(int Amt)
        {
            this.AccountBalance = this.AccountBalance + Amt;

        }

        public int GetBalance()
        {
            return this.AccountBalance;
        }
        public void Withdraw(int Amt)
        {
            this.AccountBalance = this.AccountBalance - Amt; 
                

        }
        
        public string GetDetails()
        {
            return this.AccountID+ " " + this.CustomerName;

        
    }

    }
}