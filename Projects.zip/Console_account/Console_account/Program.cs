﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_account
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Enter OrderId");
            int OrderId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" Enter CustomerName");
            String CustomerName = Console.ReadLine();
            Console.WriteLine("Enter ItemName");
            String ItemName = Console.ReadLine();
            Console.WriteLine(" Enter ItemPrice");
            int ItemPrice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" Enter ItemQuantity");
            int ItemQuantity= Convert.ToInt32(Console.ReadLine());

            Order obj = new Order(OrderId, CustomerName, ItemName, ItemPrice, ItemQuantity);
            int a = obj.OrderAmount();
            Console.WriteLine("OrderAmount:" + a);
            Console.ReadLine();


            
   

           /* Console.WriteLine(" Enter AccountID");
            int AccountID = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(" Enter CustomerName");
            String CustomerName = Console.ReadLine();

            Console.WriteLine(" AccountBalance");
            int AccountBalance = Convert.ToInt32(Console.ReadLine());

            Account obj = new Account(AccountID, CustomerName, AccountBalance);
            string details = obj.GetDetails();

            Console.WriteLine(details);

            Console.WriteLine("Enter An Amount to Deposit");
            int Amount = Convert.ToInt32(Console.ReadLine());

            obj.Deposit(Amount);

            int Balance = obj.GetBalance();
            Console.WriteLine("Balance :" + Balance);

            Console.WriteLine("Enter Amount to Withdtraw");
            Amount = Convert.ToInt32(Console.ReadLine());

            obj.Withdraw(Amount);

            Balance = obj.GetBalance();
            Console.WriteLine("Balance :" + Balance);
            */
            Console.ReadLine();
            
               





        }
    }
}
