﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1_Basics2
{
    class Program
    {
        static void Main(string[] args)
        {

            int a = 100;
            int b = a++;
            Console.WriteLine(a);
            Console.WriteLine(b);
            b = ++a;
            Console.WriteLine(a);
            Console.WriteLine(b);
                   






            int[] marks = new int[5];
            int[] marks1 = { 20, 30, 40, 50, 88 };

            marks[0] = 30;
            marks[1] = 44;
            marks[2] = 99;
            marks[3] = 77;
            marks[4] = 55;

           // Console.WriteLine(marks[0]);
           // Console.WriteLine(marks[1]);
           // Console.WriteLine(marks[2]);
           // Console.WriteLine(marks[3]);
           // Console.WriteLine(marks[4]);

            for (int count =0;count<marks.Length;count++)
            {
                Console.WriteLine(marks[count]);
            }

            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }
               
              



            int opt = 1;
            switch(opt)
            {
                case 1:
                    {
                        Console.WriteLine("It is case 1");
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("It is case 2");
                        break;
                    }
                default:
                    {
                        Console.WriteLine("It is case 3");
                        break;
                    }


            }





            int c = 0;
            while (c < 10)
            {
                Console.WriteLine(c);
                c++;
            }

            for (int i=0; i<10;i++)
            {
                Console.WriteLine(i);
            }
               
            bool flag = true;

            if (flag)
            {
                Console.WriteLine("It is true");
            }
            else
            {
                Console.WriteLine("It is flase");
            }
            Console.ReadLine();
        }
    }
}
