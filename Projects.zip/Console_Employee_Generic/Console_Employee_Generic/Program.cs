﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            Company PathFront = new Company("wipro", "pathFront,BGL");
            Console.WriteLine(PathFront.PCompanyName + " " + PathFront.PCompanyAddress);

            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1-Add,2-Search,3-Remove,4-Show,5-Request Leave, 6-Exit");
                int opt = Convert.ToInt32(Console.ReadLine());

                switch (opt)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter EmployeeName :");
                            String StudentName = Console.ReadLine();
                            Console.WriteLine("Enter EmployeeAddress :");
                            String StudentCity = Console.ReadLine();

                            Employee obj = new Employee(StudentName, StudentCity);
                            PathFront.AddEmployee(obj);

                            Console.WriteLine("Your StudentID :" + obj.PEmployeeID);

                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter CompanyAddress:");
                            int ID = Convert.ToInt32(Console.ReadLine());
                            Employee obj = PathFront.SearchEmployee(ID);
                            if (obj != null)
                            {
                                Console.WriteLine("Employee Details:");
                                Console.WriteLine(obj.PEmployeeID +" " + obj.PEmployeeName+
                                    " " + obj.PEmployeeCity);
                            }
                            else
                            {
                                Console.WriteLine("Company Not Found");
                            }


                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Enter EmployeeID:");
                            int ID = Convert.ToInt32(Console.ReadLine());

                            bool Status = PathFront.RemoveEmployee(ID);
                            if (Status == true)
                            {
                                Console.WriteLine("Employee Removed");
                            }
                            else
                            {
                                Console.WriteLine("Employee Not Found");
                            }



                            break;
                        }
                    case 4:
                        {
                            PathFront.ShowEmployee();
                            break;
                        }

                    case 5:
                        {
                            Console.WriteLine("Enter EmployeeID:");
                            int ID = Convert.ToInt32(Console.ReadLine());

                            Employee obj = PathFront.SearchEmployee(ID);
                          
                            if (obj != null)
                            {
                                Console.WriteLine("Enter the Reason:");
                                string Reason = Console.ReadLine();
                                obj.LeaveRequest(Reason);
                            }
                            else
                            {
                                Console.WriteLine("Wrong CompanyID:");
                            }


                            break;
                        }
                    case 6:
                        {
                            flag = false;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("you have entered wrong Option");
                            break;
                        }
                }


            }
        }
    }
}
