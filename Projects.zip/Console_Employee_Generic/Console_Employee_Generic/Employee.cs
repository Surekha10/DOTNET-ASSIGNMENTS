﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_Generic
{
    class Employee
    {
        private int EmployeeID;
        private String EmployeeName;
        private String EmployeeCity;
        private static int Count = 1000;

        public Employee(String EmployeeName, String EmployeeCity)
        {
            this.EmployeeID = Employee.Count++;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
        }
        public int PEmployeeID { get { return this.EmployeeID; } }

        public String PEmployeeName { get { return this.EmployeeName; } }

        public String PEmployeeCity
        {
            get { return this.EmployeeCity; }
            set { this.EmployeeCity = value; }
        }

        public void LeaveRequest(String Reason)
        {
            Console.WriteLine("EmployeeID:"
                    + this.EmployeeID + " , Reason :" + Reason);

        }

    }
}
