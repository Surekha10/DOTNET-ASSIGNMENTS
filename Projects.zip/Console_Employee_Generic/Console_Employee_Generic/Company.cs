﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_Generic
{
    class Company
    {
        private String CompanyName;
        private String CompnyAddress;
        private List<Employee> Employeelist = new List<Employee>();

        public Company (String CompanyName, String CompnyAddress)
        {
            this.CompanyName = CompanyName;
            this.CompnyAddress = CompnyAddress;
        }
        public String PCompanyName {  get { return this.CompanyName; } }
        public String PCompanyAddress {  get { return this.CompnyAddress; } }

        public void AddEmployee(Employee obj)
        {
            Employeelist.Add(obj);
            Console.WriteLine("Employee Added:");      
        }

        public Employee SearchEmployee(int ID)
        {
            foreach (Employee s in this.Employeelist)
            {
                if (s.PEmployeeID == ID)
                {
                    return s;
                }
            }
            return null;
        }

        public bool RemoveEmployee(int ID)
        {
            foreach (Employee s in this.Employeelist)
            {
                if (s.PEmployeeID == ID)
                {
                    this.Employeelist.Remove(s);
                    return true;
                }
            }
            return false;
        }

        public void ShowEmployee()
        {
            foreach(Employee s in this.Employeelist)
            {
                Console.WriteLine(s.PEmployeeID + " " + s. PEmployeeName);
            }
        }

    }
}
