﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Console_Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList List = new ArrayList();
            int x1 = 100;
            int x2 = 150;
            int x3 = 200;

            List.Add(x1);       //0
            List.Add(x2);       //1
            List.Add(x3);       //2

            int c = List.Count; //3
            List.RemoveAt(200);
            List.Remove(200);
            List.RemoveRange(1, 2);
            c = List.Count;     //2


            int y1 = Convert.ToInt32(List[1]);

            Console.WriteLine(y1);
            Console.ReadLine();
        }
    }
}
