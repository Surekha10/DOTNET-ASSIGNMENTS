﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop2
{
    class Customer
    {
        private int CustomerID;
        private String CustomerName;
        private String CustomerEmail;


        public Customer()//Default Constructor
        {
            Console.WriteLine("Default Constructor");
        }
        public Customer(int CustomerID, String CustomerName, String CustomerEmail)
        {
            this.CustomerID = CustomerID;
            this.CustomerName = CustomerName;
            this.CustomerEmail = CustomerEmail;
            Console.WriteLine("Parameter Constructor");

        }

        public String GetDetails()
        {
            return this.CustomerID + " " + this.CustomerName + " " + this.CustomerEmail;
        }
        


    }
}
