﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Employee Id");
            int EmployeeId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Employee Name");
            String EmployeeName = Console.ReadLine();

            Console.WriteLine("Enter EmployeeSalary");
            double EmployeeSalary = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Employeecity");
            String Employeecity = Console.ReadLine();

            Employee obj = new Employee(EmployeeId, EmployeeName, EmployeeSalary, Employeecity);
            string details = obj.GetDetails();
            Console.WriteLine(details);
            Console.WriteLine("Enter No of Days : ");
            int Days = Convert.ToInt32(Console.ReadLine());
            double salary = obj.Getsalary(Days);
            Console.WriteLine("Salary :" + salary);



            Console.WriteLine("Enter CustomerId");
            int CustomerId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter customer Name");
            String CustomerName = Console.ReadLine();
            Console.WriteLine("Enter customer Email");
            String CustomerEmail = Console.ReadLine();

            Customer obj = new Customer(CustomerId, CustomerName, CustomerEmail);
            String str = obj.GetDetails();

            Console.WriteLine(str);

            Console.ReadLine();

        }

    }
    }

