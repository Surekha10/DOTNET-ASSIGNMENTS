﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment_Day1_BankDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Account Id :");
            int AccountId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name:");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Customer Address :");
            string CustomerAddress = Console.ReadLine();
            Console.WriteLine("Type of Account :");
            string Typeofaccount = Console.ReadLine();
            Console.WriteLine("Balance:");
            int Balance = Convert.ToInt32(Console.ReadLine());

            bool flag = true;
            while (flag)
            {
                Console.WriteLine(" Deposit -1, withdraw -2, checkbalance -3,  Exit -4");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter Deposit");
                            int Deposit = Convert.ToInt32(Console.ReadLine());
                            if (Deposit >= 500)
                            {
                                Console.WriteLine("Deposited:" + Deposit);
                                Balance = Balance + Deposit;
                                Console.WriteLine("withdraw:" + Balance);

                            }
                            break;
                        }
                      case 2:
                            {
                            Console.WriteLine("Withdraw");
                            int withdraw = Convert.ToInt32(Console.ReadLine());

                            Balance = Balance - withdraw;
                            Console.WriteLine("withdraw:" + Balance);

                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("checkbalance:" + Balance);
                            break;
                        }
                    case 4:
                        {
                            flag = false;
                            break;
                        }


                        }
                }
            }
        }
    }

